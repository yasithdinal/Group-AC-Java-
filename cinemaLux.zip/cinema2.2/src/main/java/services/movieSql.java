package services;
	
import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;
	import java.util.List;	
	import model.movie;
	import utils.DBConnect;
	
	public class movieSql {
	
	    // Method to add movie to database, including showtimes and cast members
	    public boolean addMovie(movie movie, List<String> showtimes, List<String> castMembers) {
	        boolean isSuccess = false;
	
	        try (Connection con = DBConnect.getConnection()) {
	            // Insert movie into movies table
	            String sql = "INSERT INTO movies (title, director, release_date, genre, description, poster_path, trailerLink) VALUES (?, ?, ?, ?, ?, ?, ?)";
	            try (PreparedStatement ps = con.prepareStatement(sql)) {
	                ps.setString(1, movie.getTitle());
	                ps.setString(2, movie.getDirector());
	                ps.setDate(3, new java.sql.Date(movie.getReleaseDate().getTime()));
	                ps.setString(4, movie.getGenre());
	                ps.setString(5, movie.getDescription());
	                ps.setString(6, movie.getPosterPath());
	                ps.setString(7, movie.getTrailerLink());
	                   
	
	                int result = ps.executeUpdate();
	                if (result > 0) {
	                    // Get the generated movie ID
	                    String getIdQuery = "SELECT LAST_INSERT_ID()";
	                    try (PreparedStatement psId = con.prepareStatement(getIdQuery)) {
	                        ResultSet rs = psId.executeQuery();
	                        if (rs.next()) {
	                            int movieId = rs.getInt(1);
	
	                            // Insert showtimes into movie_showtimes table
	                            String showtimeSql = "INSERT INTO movie_showtimes (movie_id, showtime) VALUES (?, ?)";
	                            try (PreparedStatement psShowtime = con.prepareStatement(showtimeSql)) {
	                                for (String showtime : showtimes) {
	                                    psShowtime.setInt(1, movieId);
	                                    psShowtime.setString(2, showtime);
	                                    psShowtime.executeUpdate();
	                                }
	                            }
	
	                            // Insert cast members into movie_cast table
	                            String castSql = "INSERT INTO movie_cast (movie_id, cast_member) VALUES (?, ?)";
	                            try (PreparedStatement psCast = con.prepareStatement(castSql)) {
	                                for (String castMember : castMembers) {
	                                    psCast.setInt(1, movieId);
	                                    psCast.setString(2, castMember);
	                                    psCast.executeUpdate();
	                                }
	                            }
	                        }
	                    }
	                    isSuccess = true;
	                }
	            }
	        } catch (SQLException | ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        return isSuccess;
	    }
	
	    // Method to get all movies along with showtimes and cast members
	    public List<movie> getAllMovies() {
	        List<movie> movieList = new ArrayList<>();
	        try (Connection con = DBConnect.getConnection()) {
	            String sql = "SELECT * FROM movies";
	            try (PreparedStatement ps = con.prepareStatement(sql)) {
	                ResultSet rs = ps.executeQuery();
	                while (rs.next()) {
	                    int movieId = rs.getInt("id");
	                    movie movieObj = new movie(
	                        movieId,
	                        rs.getString("title"),
	                        rs.getString("director"),
	                        rs.getDate("release_date"),
	                        rs.getString("genre"),
	                        rs.getString("description"),
	                        rs.getString("poster_path"),
	                        rs.getString("trailerLink")
	                    );
	
	                    // Fetch showtimes for each movie
	                    List<String> showtimes = getShowtimesForMovie(movieId);
	                    movieObj.setShowtimes(showtimes);
	
	                    // Fetch cast members for each movie
	                    List<String> castMembers = getCastMembersForMovie(movieId);
	                    movieObj.setCastMembers(castMembers);
	
	                    movieList.add(movieObj);
	                }
	            }
	        } catch (SQLException | ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        return movieList;
	    }
	
	    // Method to get showtimes for a specific movie
	    private List<String> getShowtimesForMovie(int movieId) {
	        List<String> showtimes = new ArrayList<>();
	        try (Connection con = DBConnect.getConnection()) {
	            String sql = "SELECT showtime FROM movie_showtimes WHERE movie_id = ?";
	            try (PreparedStatement ps = con.prepareStatement(sql)) {
	                ps.setInt(1, movieId);
	                ResultSet rs = ps.executeQuery();
	                while (rs.next()) {
	                    showtimes.add(rs.getString("showtime"));
	                }
	            }
	        } catch (SQLException | ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        return showtimes;
	    }
	
	    // Method to get cast members for a specific movie
	    private List<String> getCastMembersForMovie(int movieId) {
	        List<String> castMembers = new ArrayList<>();
	        try (Connection con = DBConnect.getConnection()) {
	            String sql = "SELECT cast_member FROM movie_cast WHERE movie_id = ?";
	            try (PreparedStatement ps = con.prepareStatement(sql)) {
	                ps.setInt(1, movieId);
	                ResultSet rs = ps.executeQuery();
	                while (rs.next()) {
	                	castMembers.add(rs.getString("cast_member"));
	                }
	            }
	        } catch (SQLException | ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        return castMembers;
	    }
	
	
	
	    public boolean deleteMovie(int movieId) {
	        boolean isSuccess = false;
	        try (Connection con = DBConnect.getConnection()) {
	            // SQL query to delete the movie from the database
	            String sql = "DELETE FROM movies WHERE id = ?";
	
	            // Create a PreparedStatement to execute the SQL query
	            try (PreparedStatement ps = con.prepareStatement(sql)) {
	                // Set the movieId in the query
	                ps.setInt(1, movieId);
	
	                // Execute the update and check if rows were affected
	                int result = ps.executeUpdate();
	                if (result > 0) {
	                    // If the result is greater than 0, the movie was deleted successfully
	                    isSuccess = true;
	                }
	            }
	        } catch (SQLException | ClassNotFoundException e) {
	            // Print the stack trace for debugging
	            e.printStackTrace();
	        }
	        return isSuccess;
	    }
	
	    public movie getMovieById(int movieId) {
	        movie movie = null;
	        try (Connection con = DBConnect.getConnection()) {
	            String sql = "SELECT * FROM movies WHERE id = ?";
	            try (PreparedStatement ps = con.prepareStatement(sql)) {
	                ps.setInt(1, movieId);
	                ResultSet rs = ps.executeQuery();
	                if (rs.next()) {
	                    movie = new movie(
	                        rs.getInt("id"),
	                        rs.getString("title"),
	                        rs.getString("director"),
	                        rs.getDate("release_date"),
	                        rs.getString("genre"),
	                        rs.getString("description"),
	                        rs.getString("poster_path"),
	                        rs.getString("trailerLink")
	                    );
	                    // Fetch showtimes and cast members
	                    movie.setShowtimes(getShowtimesForMovie(movieId));
	                    movie.setCastMembers(getCastMembersForMovie(movieId));
	                }
	            }
	        } catch (SQLException | ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        return movie;
	    }

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
