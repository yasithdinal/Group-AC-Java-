package services;

import java.sql.ResultSet;
import java.sql.Statement;
import model.user;
import utils.DBConnect;

public class userSql {

    public void regUser(user User) { 
        try {
            String query = "INSERT INTO users (username, email, password) VALUES ('"
                    + User.getUsername() + "', '"
                    + User.getEmail() + "', '"
                    + User.getPassword() + "')";
            Statement statement = DBConnect.getConnection().createStatement();
            statement.executeUpdate(query);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean validate(user User) {
        try {
            String query = "SELECT * FROM users WHERE email='" + User.getEmail() + "' AND password='" + User.getPassword() + "'";
            Statement statement = DBConnect.getConnection().createStatement();
            ResultSet rs = statement.executeQuery(query);
            if (rs.next()) {
                return true; // User found, valid credentials
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false; // Invalid credentials
    }

    public boolean isAdmin(user User) {
        try {
            String query = "SELECT is_admin FROM users WHERE email='" + User.getEmail() + "' AND password='" + User.getPassword() + "'";
            Statement statement = DBConnect.getConnection().createStatement();
            ResultSet rs = statement.executeQuery(query);
            if (rs.next()) {
                return rs.getInt("is_admin") == 1; // Return true if user is admin (is_admin = 1)
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false; // User is not admin
    }
}

