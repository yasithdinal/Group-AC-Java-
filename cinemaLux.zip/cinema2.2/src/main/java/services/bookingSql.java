package services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import utils.DBConnect;

public class bookingSql {

    // Method to create booking and update seat status
    public static boolean createBooking(int userId, int showtimeId, List<String> seatNumbers, String transactionId, String paymentStatus, int movieId) throws ClassNotFoundException, SQLException {
        Connection conn = DBConnect.getConnection();
        PreparedStatement stmt = null;
        boolean isSuccess = false;

        try {
            // Check if seats are available
            if (!areSeatsAvailable(conn, showtimeId, seatNumbers)) {
                return false; // Some seats are already booked
            }

            // Start a transaction
            conn.setAutoCommit(false);

            // Insert booking records
            for (String seatNumber : seatNumbers) {
                String insertBooking = "INSERT INTO bookings (user_id, seat_id, showtime_id, status, payment_status, transaction_id, movie_id) "
                        + "SELECT ?, seat_id, ?, 'booked', ?, ?, ? FROM seats WHERE seat_number = ? AND showtime_id = ?";
                stmt = conn.prepareStatement(insertBooking);
                stmt.setInt(1, userId);
                stmt.setInt(2, showtimeId);
                stmt.setString(3, paymentStatus);
                stmt.setString(4, transactionId);
                stmt.setInt(5, movieId);
                stmt.setString(6, seatNumber);
                stmt.setInt(7, showtimeId);
                stmt.executeUpdate();
            }

            // Update seat statuses to 'BOOKED'
            updateSeatStatus(conn, seatNumbers, showtimeId);

            // Commit the transaction
            conn.commit();
            isSuccess = true;
        } catch (SQLException e) {
            conn.rollback(); // Rollback on error
            e.printStackTrace();
        } finally {
            closeResources(stmt, conn);
        }

        return isSuccess;
    }

    // Method to get showtimeId based on showtime string
    public static int getShowtimeIdByShowtime(String showtime) throws SQLException, ClassNotFoundException {
        Connection conn = DBConnect.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int showtimeId = 0;

        try {
            String query = "SELECT showtime_id FROM movie_showtimes WHERE showtime = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, showtime);
            rs = stmt.executeQuery();

            if (rs.next()) {
                showtimeId = rs.getInt("showtime_id");
            }
        } finally {
            if (stmt != null) stmt.close();
            if (rs != null) rs.close();
        }

        return showtimeId;
    }

    // Method to check if a seat is available
    public static boolean isSeatAvailable(int showtimeId, String seatNumber) throws SQLException, ClassNotFoundException {
        Connection conn = DBConnect.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        boolean isAvailable = true;

        try {
            String query = "SELECT status FROM seats WHERE seat_number = ? AND showtime_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, seatNumber);
            stmt.setInt(2, showtimeId);
            rs = stmt.executeQuery();

            if (rs.next()) {
                if (rs.getString("status").equals("BOOKED")) {
                    isAvailable = false; // Seat is already booked
                }
            }
        } finally {
            if (stmt != null) stmt.close();
            if (rs != null) rs.close();
        }

        return isAvailable;
    }

    // Helper method to check if all seats are available
    private static boolean areSeatsAvailable(Connection conn, int showtimeId, List<String> seatNumbers) throws SQLException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        for (String seatNumber : seatNumbers) {
            String seatQuery = "SELECT status FROM seats WHERE seat_number = ? AND showtime_id = ?";
            stmt = conn.prepareStatement(seatQuery);
            stmt.setString(1, seatNumber);
            stmt.setInt(2, showtimeId);
            rs = stmt.executeQuery();

            if (rs.next() && rs.getString("status").equals("BOOKED")) {
                return false; // Some seats are already booked
            }
        }
        return true;
    }

    // Helper method to update seat status
    public static void updateSeatStatus(Connection conn, List<String> seatNumbers, int showtimeId) throws SQLException {
        PreparedStatement stmt = null;
        for (String seatNumber : seatNumbers) {
            String updateSeatStatus = "UPDATE seats SET status = 'BOOKED' WHERE seat_number = ? AND showtime_id = ?";
            stmt = conn.prepareStatement(updateSeatStatus);
            stmt.setString(1, seatNumber);
            stmt.setInt(2, showtimeId);
            stmt.executeUpdate();
        }
    }

    // Helper method to close resources
    private static void closeResources(PreparedStatement stmt, Connection conn) {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.setAutoCommit(true); // Restore default autocommit mode
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // New method to update the payment status after payment processing
    public static boolean updatePaymentStatus(String transactionId, String paymentStatus) throws SQLException, ClassNotFoundException {
        Connection conn = DBConnect.getConnection();
        PreparedStatement stmt = null;
        boolean isUpdated = false;

        try {
            String updatePaymentStatus = "UPDATE bookings SET payment_status = ? WHERE transaction_id = ?";
            stmt = conn.prepareStatement(updatePaymentStatus);
            stmt.setString(1, paymentStatus);
            stmt.setString(2, transactionId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                isUpdated = true;
            }
        } finally {
            if (stmt != null) stmt.close();
            conn.close();
        }

        return isUpdated;
    }

    // New method to process payment and return boolean indicating success/failure
    public static boolean processPayment(String transactionId, String paymentStatus) throws SQLException, ClassNotFoundException {
        // Update the payment status
        return updatePaymentStatus(transactionId, paymentStatus);
    }
}
