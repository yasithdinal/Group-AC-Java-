package utils;

import com.braintreegateway.*;
import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

public class PayPalPaymentUtils {
    
    // Initialize the Braintree Gateway with your sandbox credentials
    private static final BraintreeGateway gateway = new BraintreeGateway(
        Environment.SANDBOX,  // Use Environment.PRODUCTION for live transactions
        "rwbz6ks4zygjdw37",   // Merchant ID
        "sgtt3yjb7828gtfh",   // Public Key
        "c7a0f60885647855ce53259794b8cc50"  // Private Key
    );

    public static String initiatePayment(int userId, List<String> seatNumbers, String showtime, String nonceFromTheClient) {
        // Generate a unique transaction ID
        String transactionId = "txn_" + System.currentTimeMillis();

        // Calculate the total amount dynamically based on seat count
        BigDecimal totalAmount = new BigDecimal(seatNumbers.size() * 20); // Example: 20 per seat

        // Set up the payment request
        TransactionRequest request = new TransactionRequest()
            .amount(totalAmount)
            .paymentMethodNonce(nonceFromTheClient) // Using the actual nonce from frontend
            .orderId(transactionId)
            .options()
                .submitForSettlement(true)
                .done();

        // Create the transaction
        Result<Transaction> result = gateway.transaction().sale(request);

        if (result.isSuccess()) {
            // If payment is successful, return the actual transaction ID
            return result.getTransaction().getId();
        } else {
            // Handle payment failure
            return null;
        }
    }



    // Method to process the payment (after user is redirected to PayPal and returns back)
    public static boolean processPayment(int userId, String transactionId, List<String> seatNumbers, String showtime, HttpServletResponse response) {
        // You can use this method to handle payment processing confirmation after redirection from PayPal
        Transaction transaction = gateway.transaction().find(transactionId);
        
        if (transaction.getStatus() == Transaction.Status.SETTLED) {
            // If the payment is successful, update your booking and database
            // Proceed with booking confirmation
            // Update the payment status in the database, mark seats as booked, etc.
            System.out.println("Payment Success for transaction ID: " + transactionId);
        } else {
            // Handle failed payment (transaction was not settled)
            System.out.println("Payment failed for transaction ID: " + transactionId);
        }
		return false;
        
        // Redirect the user or show an appropriate message based on the result
    }
}
