package utils;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {

	public static Connection getConnection () throws ClassNotFoundException, SQLException {

		String username="root";
		String password="1234";

		Class.forName("com.mysql.cj.jdbc.Driver");

		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cinema?useSSL=false&serverTimezone=UTC", username, password);

		return con ;		
		
	}

}
