package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import utils.DBConnect;

@WebServlet("/feedbackServlet")
public class feedbackServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get feedback details from the form
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String feedbackText = request.getParameter("feedback_text");

        // Database connection setup
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            // Use DBConnect to get the connection
            conn = DBConnect.getConnection();

            // SQL to insert feedback into the database
            String sql = "INSERT INTO feedback (username, email, feedback_text) VALUES (?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, email);
            ps.setString(3, feedbackText);

            // Execute the query
            int rowsAffected = ps.executeUpdate();

            // If feedback was submitted successfully, redirect to a confirmation page or the same page
            if (rowsAffected > 0) {
                response.sendRedirect("index.jsp"); // Optionally create a feedback success page
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("feedbackError.jsp");
        } finally {
            try {
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
