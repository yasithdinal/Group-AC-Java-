package servlet;

import com.braintreegateway.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/clientToken")
public class clientTokenServlet extends HttpServlet {

    private static final BraintreeGateway gateway = new BraintreeGateway(
        Environment.SANDBOX, 
        "rwbz6ks4zygjdw37", 
        "sgtt3yjb7828gtfh", 
        "c7a0f60885647855ce53259794b8cc50"
    );

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Generate the client token
        String clientToken = gateway.clientToken().generate();
        
        // Return the token as JSON
        response.setContentType("application/json");
        response.getWriter().write("{\"clientToken\": \"" + clientToken + "\"}");
    }
}
