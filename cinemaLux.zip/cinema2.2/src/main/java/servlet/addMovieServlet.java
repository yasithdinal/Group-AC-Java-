package servlet;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.movie;
import services.movieSql;

@WebServlet("/addMovieServlet")
public class addMovieServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String title = request.getParameter("title");
        String director = request.getParameter("director");
        String releaseDate = request.getParameter("releaseDate");
        String genre = request.getParameter("genre");
        String description = request.getParameter("description");
        String posterPath = request.getParameter("posterPath");
        String trailerLink=request.getParameter("trailerLink");

        // Parse showtimes
        String[] showtimesArray = request.getParameterValues("showtime[]");
        List<String> showtimes = new ArrayList<>();
        for (String showtime : showtimesArray) {
            showtimes.add(showtime);
        }

        // Parse cast members 
        String[] castMembersArray = request.getParameterValues("cast[]");
        List<String> castMembers = new ArrayList<>();
        if (castMembersArray != null) {
            for (String castMember : castMembersArray) {
                castMembers.add(castMember);
            }
        }
        
        // Create a movie object and store values
        movie movie = new movie(0, title, director, java.sql.Date.valueOf(releaseDate), genre, description, posterPath,trailerLink);

        // Insert movie into DB
        movieSql movieService = new movieSql();
        boolean success = movieService.addMovie(movie, showtimes, castMembers);  

        if (success) {
            // Clearing the session to fetch updated movies list
            request.getSession().removeAttribute("movies");
            response.sendRedirect("adminMovServlet");
        } else {
            response.sendRedirect("addMovie.jsp");
        }
    }
}
