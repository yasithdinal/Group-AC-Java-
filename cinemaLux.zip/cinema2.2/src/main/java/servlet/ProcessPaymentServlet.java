package servlet;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import services.bookingSql;
import utils.PayPalPaymentUtils;

@WebServlet("/processPayment")
public class ProcessPaymentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the payment nonce from the request
        String nonceFromTheClient = request.getParameter("nonce");

        // Simulate booking details, you may replace these with actual values from session or database
        int userId = 123; // Get user ID from session or database
        List<String> seatNumbers = List.of("A1", "A2"); // Example seat numbers
        String showtime = "2024-12-27 10:00"; // Example showtime

        try {
            // Get the showtime ID
            int showtimeId = bookingSql.getShowtimeIdByShowtime(showtime);

            
            

            // Call PayPalPaymentUtils to initiate the payment and get the transaction ID
            String transactionId = PayPalPaymentUtils.initiatePayment(userId, seatNumbers, showtime, nonceFromTheClient);

            // Check if the transaction was successful
            if (transactionId != null) {
                // Assume payment was successful, now update the database
                boolean paymentProcessed = bookingSql.processPayment(transactionId, "paid");

                if (paymentProcessed) {
                    // After processing the payment, create the booking and update seat status
                    boolean bookingCreated = bookingSql.createBooking(userId, showtimeId, seatNumbers, transactionId, "paid", movieId);

                    if (bookingCreated) {
                        // Update seat status in the database
                        bookingSql.updateSeatStatus(null, seatNumbers, showtimeId);

                        // Return success response
                        response.setContentType("application/json");
                        response.getWriter().write("{\"success\": true, \"message\": \"Payment successful, booking created.\"}");
                    } else {
                        // Handle failure to create booking
                        response.setContentType("application/json");
                        response.getWriter().write("{\"success\": false, \"message\": \"Failed to create booking.\"}");
                    }
                } else {
                    // Handle failure in processing the payment
                    response.setContentType("application/json");
                    response.getWriter().write("{\"success\": false, \"message\": \"Payment processing failed.\"}");
                }
            } else {
                // Handle case where transactionId is null (payment initiation failed)
                response.setContentType("application/json");
                response.getWriter().write("{\"success\": false, \"message\": \"Payment initiation failed.\"}");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"Error during payment processing or booking.\"}");
        }
    }
}
