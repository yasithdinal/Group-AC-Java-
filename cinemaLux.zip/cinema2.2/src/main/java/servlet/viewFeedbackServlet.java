package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Feedback;
import utils.DBConnect;

@WebServlet("/viewFeedbackServlet")
public class viewFeedbackServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Feedback> feedbackList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            // Get connection
            conn = DBConnect.getConnection();

            // SQL query to retrieve feedback
            String sql = "SELECT username, email, feedback_text FROM feedback";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            // Collect feedback data into a list of Feedback objects
            while (rs.next()) {
                String username = rs.getString("username");
                String email = rs.getString("email");
                String feedbackText = rs.getString("feedback_text");

                Feedback feedback = new Feedback(username, email, feedbackText);
                feedbackList.add(feedback);
            }

            // Store feedback list in session
            request.getSession().setAttribute("feedbackList", feedbackList);

            // Forward to JSP
            RequestDispatcher dispatcher = request.getRequestDispatcher("viewFeedback.jsp");
            dispatcher.forward(request, response);

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
