package servlet;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.user;
import services.userSql;

@WebServlet("/addUser")
public class addUser extends HttpServlet {
	private static final long serialVersionUID = 1L;   
  
    public addUser() {
        super();    
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		user User= new user(); //accessing the user class
		
		User.setEmail(request.getParameter("email"));
		User.setUsername(request.getParameter("username"));    //assigning the values in the users class with input values using setters
	    User.setPassword(request.getParameter("password"));  
		
		//object of the sql  
		userSql usersql = new userSql();
	    usersql.regUser(User);
	    RequestDispatcher rd= request.getRequestDispatcher("login.jsp");
	    rd.forward(request, response);
		
	}

}
