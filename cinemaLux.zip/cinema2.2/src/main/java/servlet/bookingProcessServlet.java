package servlet;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import services.bookingSql;
import utils.PayPalPaymentUtils;

@WebServlet("/bookingProcessServlet")
public class bookingProcessServlet extends HttpServlet {
   
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the session
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        // If the user is not logged in, redirect to login page
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Retrieve other request parameters
        String showtime = request.getParameter("showtime");
        String[] selectedSeats = request.getParameterValues("seats");
        String movieIdStr = request.getParameter("movieId");
        int movieId = Integer.parseInt(movieIdStr);

        
        
        System.out.println(showtime);
        

        if (selectedSeats != null && selectedSeats.length > 0) {
            // Step 1: Retrieve showtimeId based on the provided showtime
            int showtimeId = 0;
            try {
                showtimeId = bookingSql.getShowtimeIdByShowtime(showtime);
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }

            if (showtimeId == 0) {
                request.setAttribute("errorMessage", "Invalid showtime.");
                request.getRequestDispatcher("booking.jsp").forward(request, response);
                return;
            }

            // Step 2: Check seat availability
            boolean isAvailable = true;
            for (String seat : selectedSeats) {
                try {
                    if (!bookingSql.isSeatAvailable(showtimeId, seat)) {
                        isAvailable = false;
                        break;
                    }
                } catch (ClassNotFoundException | SQLException e) {
                    e.printStackTrace();
                }
            }

            if (isAvailable) {
                // Step 3: Prepare seat numbers list
                List<String> seatNumbers = new ArrayList<>();
                Collections.addAll(seatNumbers, selectedSeats);

                // Step 4: Initiate payment
                String transactionId = PayPalPaymentUtils.initiatePayment(userId, seatNumbers, showtime, transactionId);
                String paymentStatus = "PENDING"; // Set to PENDING until payment is confirmed

                // Step 5: Process payment
                boolean paymentSuccess = PayPalPaymentUtils.processPayment(userId, transactionId, seatNumbers, showtime, response);
                if (paymentSuccess) {
                    // Step 6: Insert booking into the database
                    try {
                        boolean bookingSuccess = bookingSql.createBooking(userId, showtimeId, seatNumbers, transactionId, "SUCCESS",movieId);
                        if (bookingSuccess) {
                            // Redirect to booking confirmation page
                            response.sendRedirect("bookingSuccess.jsp");
                        } else {
                            request.setAttribute("errorMessage", "Booking failed. Please try again.");
                            request.getRequestDispatcher("booking.jsp").forward(request, response);
                        }
                    } catch (ClassNotFoundException | SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    // If payment fails, update payment status and show an error message
                    try {
                        bookingSql.updatePaymentStatus(transactionId, "FAILED");
                    } catch (ClassNotFoundException | SQLException e) {
                        e.printStackTrace();
                    }
                    request.setAttribute("errorMessage", "Payment failed. Please try again.");
                    request.getRequestDispatcher("booking.jsp").forward(request, response);
                }

            } else {
                // If seats are not available, show an error message
                request.setAttribute("errorMessage", "Some seats are already booked. Please choose other seats.");
                request.getRequestDispatcher("booking.jsp").forward(request, response);
            }

        } else {
            // If no seats were selected, show an error message
            request.setAttribute("errorMessage", "Please select at least one seat.");
            request.getRequestDispatcher("booking.jsp").forward(request, response);
        }
    }
}
