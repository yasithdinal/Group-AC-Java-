package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import services.movieSql;

@WebServlet("/deleteMovieServlet")
public class deleteMovieServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Retrieve movie ID from request
            int movieId = Integer.parseInt(request.getParameter("movieId"));

            // Create an instance of movieSql service to delete movie
            movieSql movieService = new movieSql();

            // Attempt to delete the movie from DB
            boolean success = movieService.deleteMovie(movieId);

            // If successful, remove the session attribute and redirect to movie list
            if (success) {
                // Clear the session to fetch the updated movies list
                request.getSession().removeAttribute("movies");
                response.sendRedirect("adminMovServlet");
            } else {
                // If deletion failed, redirect back to the movie list page
                response.sendRedirect("adminMov.jsp");
            }
        } catch (NumberFormatException e) {
            // Handle case where movieId is not a valid integer
            e.printStackTrace();  // Log the error (you can replace it with proper logging)
            response.sendRedirect("errorPage.jsp");  // Redirect to an error page
        } catch (Exception e) {
            // Handle other exceptions
            e.printStackTrace();
            response.sendRedirect("errorPage.jsp");  // Redirect to an error page
        }
    }
}
