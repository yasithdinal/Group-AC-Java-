package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.movie;
import services.movieSql;

@WebServlet("/bookingServlet")
public class bookingServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Retrieve session attributes
        String userEmail = (String) request.getSession().getAttribute("email");

        // Check if the user is logged in
        if (userEmail == null || userEmail.isEmpty()) {
            // If not logged in, redirect to the login page
            response.sendRedirect("login.jsp");
            return;
        }

        // If logged in, proceed with booking logic
        String movieIdStr = request.getParameter("movieId");

        if (movieIdStr != null && !movieIdStr.isEmpty()) {
            int movieId = Integer.parseInt(movieIdStr);

            // Fetch the movie details from the database
            movie movieObj = new movieSql().getMovieById(movieId);

            // Set the movie details and showtimes as request attributes
            if (movieObj != null) {
                request.setAttribute("movie", movieObj);
                request.setAttribute("movieTitle", movieObj.getTitle());  // Setting the movie title
                request.setAttribute("showtimes", movieObj.getShowtimes());  // Setting the showtimes (assuming 'getShowtimes' returns a list)
            }

            // Forward the request to the booking page
            request.getRequestDispatcher("booking.jsp").forward(request, response);

        } else {
            // If movieId is not found, redirect to an error page
            response.sendRedirect("errorPage.jsp");
        }
    }
}
