package servlet;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.user;
import services.userSql;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public loginServlet() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        user User = new user();
        User.setEmail(request.getParameter("email"));
        User.setPassword(request.getParameter("password"));  // Setting the values from the form into the values using setters in the user.java

        userSql usersql = new userSql();
        boolean isValidUser = usersql.validate(User);

        if (isValidUser) {
            // Check if the user is an admin
            boolean isAdmin = usersql.isAdmin(User);

            HttpSession session = request.getSession();
            session.setAttribute("email", User.getEmail()); // Storing user email in session
            session.setAttribute("isAdmin", isAdmin); // Storing admin status
            session.setAttribute("username", User.getUsername());

            // Redirect based on admin status
            if (isAdmin) {
                RequestDispatcher dis = request.getRequestDispatcher("admin.jsp");
                dis.forward(request, response);
            } else {
                RequestDispatcher dis = request.getRequestDispatcher("index.jsp");
                dis.forward(request, response);
            }
        } else {
            RequestDispatcher dis = request.getRequestDispatcher("login_failed.jsp");
            dis.forward(request, response);
        }
    }
}



