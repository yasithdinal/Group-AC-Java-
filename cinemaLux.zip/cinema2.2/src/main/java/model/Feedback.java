package model;

public class Feedback {
    private String username;
    private String email;
    private String feedbackText;

    public Feedback(String username, String email, String feedbackText) {
        this.username = username;
        this.email = email;
        this.feedbackText = feedbackText;
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getFeedbackText() {
        return feedbackText;
    }
}
